package com.example.cadastro

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioButton

class MainActivity : AppCompatActivity() {

    lateinit var name: EditText
    lateinit var lastName: EditText
    lateinit var email: EditText
    lateinit var phoneNumber: EditText
    lateinit var sexo: RadioButton
    lateinit var limpar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        name = findViewById(R.id.name) as EditText
        lastName = findViewById(R.id.lastName) as EditText
        email = findViewById(R.id.email) as EditText
        phoneNumber = findViewById(R.id.phoneNumber) as EditText
        limpar = findViewById(R.id.limpar) as Button

        limpar.setOnClickListener {
            name.text.clear()
            lastName.text.clear()
            email.text.clear()
            phoneNumber.text.clear()
            }





















    }
}