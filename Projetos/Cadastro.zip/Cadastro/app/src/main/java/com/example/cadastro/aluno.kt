package com.example.cadastro

class aluno( var name: String, var lastName: String, var email: String, var phoneNumber: String) {

}