package com.example.calculadora

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    lateinit var valor1: EditText
    lateinit var valor2: EditText
    lateinit var Button1: Button
    lateinit var Button2: Button
    lateinit var Button3: Button
    lateinit var Button4: Button
    lateinit var resultado: TextView
    lateinit var limpar: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Mova setContentView para o início do método onCreate
        setContentView(R.layout.activity_main)

        valor1 = findViewById(R.id.valor1) as EditText
        valor2 = findViewById(R.id.valor2) as EditText
        Button1 = findViewById(R.id.button) as Button
        Button2 = findViewById(R.id.button2) as Button
        Button3 = findViewById(R.id.button3) as Button
        Button4 = findViewById(R.id.button4) as Button
        resultado = findViewById(R.id.resultado) as TextView
        limpar = findViewById(R.id.limpar) as Button


        Button1.setOnClickListener { somar(it) }
        Button2.setOnClickListener { subtrair(it) }
        Button3.setOnClickListener { dividir(it) }
        Button4.setOnClickListener { multiplicar(it) }

        limpar.setOnClickListener {
            valor1.text.clear()
            valor2.text.clear()
            resultado.text = ""
        }
    }

    fun somar(view: View) {
        var num = valor1.text.toString().toDouble()
        var num2 = valor2.text.toString().toDouble()
        var result = num + num2

        resultado.text = "O resultado é: $result"
    }

    fun multiplicar(view: View){
        var num = valor1.text.toString().toDouble()
        var num2 = valor2.text.toString().toDouble()
        var result = num * num2

        resultado.text = "O resultado é: $result"
    }

    fun dividir(view: View){
        var num = valor1.text.toString().toDouble()
        var num2 = valor2.text.toString().toDouble()
        var result = num / num2

        resultado.text = "O resultado é: $result"
    }

    fun subtrair(view: View){
        var num = valor1.text.toString().toDouble()
        var num2 = valor2.text.toString().toDouble()
        var result = num - num2

        resultado.text = "O resultado é: $result"
    }


}
